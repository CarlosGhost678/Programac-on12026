using System;

class Program
{
    static void Main()
    {
        double[,] compras = {
            {50, 20, 10, 5, 10},
            {200, 100, 50, 80, 70},
            {500, 300, 200, 100, 50},
            {20, 30, 10, 5, 5},
            {1000, 200, 300, 150, 100}
        };

        CalcularDescuentos(compras);
    }

    static void CalcularDescuentos(double[,] datos)
    {
        for (int i = 0; i < datos.GetLength(0); i++) // recorrer clientes (filas)
        {
            double total = 0;

            for (int j = 0; j < datos.GetLength(1); j++) // recorrer compras
            {
                total += datos[i, j];
            }

            double descuento = 0;

            if (total >= 100 && total <= 1000)
                descuento = total * 0.10;
            else if (total > 1000)
                descuento = total * 0.20;

            Console.WriteLine("Cliente " + (i + 1));
            Console.WriteLine("Total: " + total);
            Console.WriteLine("Descuento: " + descuento);
            Console.WriteLine("---------------------");
        }
    }
}