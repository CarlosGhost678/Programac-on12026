using System;

class Program
{
    static void Main()
    {
        string[] t = new string[10];
        int c = 0, op;

        do
        {
            Console.WriteLine("\n1.Mostrar 2.Agregar 3.Eliminar 4.Salir");
            op = int.Parse(Console.ReadLine());

            if (op == 1)
                for (int i = 0; i < c; i++)
                    Console.WriteLine((i+1) + ". " + t[i]);

            if (op == 2)
                t[c++] = Console.ReadLine();

            if (op == 3)
            {
                int n = int.Parse(Console.ReadLine());
                for (int i = n-1; i < c-1; i++)
                    t[i] = t[i+1];
                c--;
            }

        } while (op != 4);
    }
}