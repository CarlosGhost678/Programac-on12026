using System;

class Program
{
    static void Main()
    {
        char[,] t = new char[3,3];
        char j = 'X';

        for (int k = 0; k < 9; k++)
        {
            Console.Clear();

            // Mostrar tablero
            for (int i = 0; i < 3; i++)
            {
                Console.WriteLine($"{t[i,0]} | {t[i,1]} | {t[i,2]}");
            }

            Console.WriteLine("Turno: " + j);
            Console.Write("Fila (0-2): ");
            int f = int.Parse(Console.ReadLine());
            Console.Write("Columna (0-2): ");
            int c = int.Parse(Console.ReadLine());

            if (t[f,c] == '\0') // vacío
            {
                t[f,c] = j;

                // Verificar ganador (forma corta)
                if ((t[0,0]==j && t[0,1]==j && t[0,2]==j) ||
                    (t[1,0]==j && t[1,1]==j && t[1,2]==j) ||
                    (t[2,0]==j && t[2,1]==j && t[2,2]==j) ||
                    (t[0,0]==j && t[1,0]==j && t[2,0]==j) ||
                    (t[0,1]==j && t[1,1]==j && t[2,1]==j) ||
                    (t[0,2]==j && t[1,2]==j && t[2,2]==j) ||
                    (t[0,0]==j && t[1,1]==j && t[2,2]==j) ||
                    (t[0,2]==j && t[1,1]==j && t[2,0]==j))
                {
                    Console.Clear();
                    for (int i = 0; i < 3; i++)
                        Console.WriteLine($"{t[i,0]} | {t[i,1]} | {t[i,2]}");

                    Console.WriteLine("Gana: " + j);
                    return;
                }

                j = (j == 'X') ? 'O' : 'X';
            }
            else
            {
                Console.WriteLine("Ocupado!");
                k--;
                Console.ReadKey();
            }
        }

        Console.WriteLine("Empate");
    }
}

