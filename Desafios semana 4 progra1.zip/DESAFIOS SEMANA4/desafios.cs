using System; 

class program
{
    static void Main()
    {
        Console.WriteLine("Ingresu un número entero positivo");
        int numero = int.Parse(Console.ReadLine());

        for (int i = 1; i <= numero; i++)
        {
            if (i % 2 != 0)
            {
                continue;
            }

            Console.WriteLine(i);
        }
    }
}