using System;
using System.Runtime.InteropServices.Marshalling;

class program
{
    static void Main()
    {
        int suma = 0;
        int contador = 0;

        Console.WriteLine("Ingrese notas entre 1 y 10. Fin para terminar");

        while (true)
        {
            Console.Write("Nota: ");
            string entrada = Console.ReadLine();

            if (entrada == "fin")
                break;

                int nota;

                if (int.TryParse(entrada, out nota))
            {
                if (nota >= 1 && nota <= 10)
                {
                    suma += nota;
                    contador++;
                }
                else
                {
                    Console.WriteLine("La nota debe estar entre 1 y 10");
                }
            }
            else
            {
                if (contador > 0)
                {
                    double promedio = (double)suma / contador;
                    Console.WriteLine("El promedio es: " + promedio);
                }
                else
                {
                    Console.WriteLine("No se ingresaron notas");
                }
            }
        }
    }
}