using System;

class program
{
    static void Main()
    {
        Console.Write("Ingrese un número entero positivo: ");
        int numero = int.Parse(Console.ReadLine());

        bool esPrimo = true;

        for (int i = 2; i < numero; i++)
        {
            if (numero % i == 0)
            {
                esPrimo = false;
                Console.WriteLine("El numero no es primo");
                break;
            }
        }

        if (esPrimo && numero > 1)
        {
            Console.WriteLine("El número es primo");
        }
    }
}