string nombre = "Ana";
int edad = 30;

//Prueba del video
Console.WriteLine("Nombre de usuario:" + nombre);
Console.WriteLine("Edad " + edad);


//COMENTARIOOOSSS
Console.WriteLine($"Nombre usuario: {nombre}, edad en 10 años: {edad}");

Console.ReadKey();